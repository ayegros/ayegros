--
-- PostgreSQL database dump
--

-- Dumped from database version 9.2.4
-- Dumped by pg_dump version 9.2.4
-- Started on 2018-01-07 20:19:19

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 1927 (class 1262 OID 12002)
-- Dependencies: 1926
-- Name: postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- TOC entry 171 (class 3079 OID 11727)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 1930 (class 0 OID 0)
-- Dependencies: 171
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- TOC entry 170 (class 3079 OID 16384)
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- TOC entry 1931 (class 0 OID 0)
-- Dependencies: 170
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


SET search_path = public, pg_catalog;

--
-- TOC entry 169 (class 1259 OID 32768)
-- Name: sec_tarea; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sec_tarea
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 99999
    CACHE 1;


ALTER TABLE public.sec_tarea OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 168 (class 1259 OID 24576)
-- Name: tarea; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tarea (
    id numeric(19,0) NOT NULL,
    descripcion character varying(1000) NOT NULL,
    titulo character varying(255) NOT NULL,
    fecha timestamp without time zone
);


ALTER TABLE public.tarea OWNER TO postgres;

--
-- TOC entry 1932 (class 0 OID 0)
-- Dependencies: 169
-- Name: sec_tarea; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sec_tarea', 1, false);


--
-- TOC entry 1920 (class 0 OID 24576)
-- Dependencies: 168
-- Data for Name: tarea; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tarea (id, descripcion, titulo, fecha) FROM stdin;
1	Tomar vitaminas.	Tomar vitaminas.	2018-01-06 17:02:45.278
2	Ir al gym.	Ir al gym.	2018-01-06 17:03:15.148
3	Reunirme con las chicas.	Reunirme con las chicas.	2018-01-06 17:03:58.149
4	Ir al cine	Ir al cine	2018-01-06 17:04:15.187
5	Hacer la tesis.	Hacer la tesis.	2018-01-06 17:04:39.529
\.


--
-- TOC entry 1919 (class 2606 OID 24583)
-- Name: id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tarea
    ADD CONSTRAINT id_pk PRIMARY KEY (id);


--
-- TOC entry 1929 (class 0 OID 0)
-- Dependencies: 5
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2018-01-07 20:19:19

--
-- PostgreSQL database dump complete
--

