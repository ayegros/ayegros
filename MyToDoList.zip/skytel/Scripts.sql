﻿ CREATE TABLE TAREA(
					ID numeric(19,0) NOT NULL CONSTRAINT ID_PK PRIMARY KEY,
					DESCRIPCION VARCHAR(1000) NOT NULL,
					TITULO VARCHAR(255) NOT NULL,
					FECHA timestamp without time zone
					);

select * from tarea;

--
 create sequence sec_tarea
  start with 1
  increment by 1
  maxvalue 99999
  minvalue 1;