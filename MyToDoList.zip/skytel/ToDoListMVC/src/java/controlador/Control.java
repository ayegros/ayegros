/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import entidades.Tarea;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Operaciones;

/**
 *
 * @author alexis
 */
@WebServlet(name = "Control", urlPatterns = {"/Control"})
public class Control extends HttpServlet {

    public Control() {
        super();
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Control</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Control at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        String accion = request.getParameter("accion");
        switch (accion) {
            case "listar": {
//			llamada al metodo listarTarea 
                ArrayList<Tarea> lp = Operaciones.listarTareas();
                //crear un atributo para el envio de los datos al jsp
                request.setAttribute("lista", lp);
//			redireccionar al jsp que permitira visualizar los datos
                request.getRequestDispatcher("index2.jsp").forward(request, response);
                break;
            }

            case "guardar": {

                // Obtengo los datos de la peticion
                String vector = request.getParameter("vector");
                String[] parts = vector.split(",");

                /*Recorro el array e inserto los datos nuevos y modifico los viejos */
                for (String elemento : parts) {
                    if ("0".equals(elemento)) {
                        Tarea p = new Tarea();
                        if (request.getParameter("id").matches("[0-9]+")) {
                            p.setId(Integer.parseInt(elemento));
                            p.setDescripcion(request.getParameter("descripcion"));
                            p.setTitulo(request.getParameter("titulo"));
                            p.setFecha(null);//será now()
                            
                            Operaciones.nuevaTarea(p);
                        }

                    } else {

                    }

                }
//			redireccionar al listado
                request.getRequestDispatcher("Control?accion=listar").forward(request, response);

                break;
            }

        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
