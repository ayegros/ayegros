/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import bd.Conexion;
import entidades.Tarea;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author alexis
 */
public class Operaciones {

    public static ArrayList<Tarea> listarTareas() {
//		consulta a la base de datos
        String consulta = "SELECT id, descripcion, titulo, fecha "
                + "  FROM public.tarea; ";
        //objeto de retorno
        ArrayList<Tarea> lp = new ArrayList<>();

//		obtener la conexion
        try (
                //conexion
                Connection con = Conexion.obtenerCon();
                //crear una sentencia
                Statement stm = con.createStatement();
                //crear un conjunto de resultados y
                //ejecutar la consulta
                ResultSet rs = stm.executeQuery(consulta);) {

//			crear el objeto Tarea
            Tarea ps = null;

//			recorrer el conjunto de resultados
            while (rs.next()) {

                ps = new Tarea(rs.getInt("id"),
                        rs.getString("descripcion"),
                        rs.getString("titulo"),
                        rs.getTimestamp("fecha")); //<- el objeto ciudad que contiene a pais

                //agregar a la lista cada persona
                lp.add(ps);
            }
        } catch (Exception e) {
            System.out.println("No se pudo realizar la consulta para "
                    + "listar tareas, " + e);
        }
//		retornar la lista
        return lp;
    }

    public static void nuevaTarea(Tarea p) {

        String consulta = "insert into tarea(id, descripcion, titulo, fecha) "
                + "values(select nextval('sec_tarea'),?,?,now());";
        try (
                Connection con = Conexion.obtenerCon();
                PreparedStatement pstm = con.prepareStatement(consulta);) {

            pstm.setString(2, p.getDescripcion());
            pstm.setString(3, p.getTitulo());

            pstm.execute();

        } catch (Exception e) {
            System.out.println("No se pudo realizar la consulta "
                    + "para insertar Tarea, " + e);
        }
    }

}
