/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bd;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author alexis
 */
public class Conexion {

    public static Connection obtenerCon() throws SQLException,
            FileNotFoundException {
        Connection con = null;
        
        String url = "jdbc:postgresql://localhost:5432/postgres";
        
        try {
//			obtener el driver
            Class.forName("org.postgresql.Driver");
//			obtener la conexion
            con = DriverManager.getConnection(url, "postgres",
                    "postgres");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error al conectar a la "
                    + "Base de Datos, " + e);
        }
//		retornar la conexion
        return con;
    }

}
